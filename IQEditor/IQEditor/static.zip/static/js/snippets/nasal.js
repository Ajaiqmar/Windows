
;                (function() {
                    ace.require(["ace/snippets/nasal"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            